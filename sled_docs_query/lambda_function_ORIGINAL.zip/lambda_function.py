import boto3
import json

def lambda_handler(event, context):
    # Handle both direct JSON and API Gateway string body
    body = event
    if 'body' in event:
        try:
            body = json.loads(event['body'])
        except (json.JSONDecodeError, TypeError):
            body = event.get('body', {})
    
    query = body.get('query', '')
    
    if not query:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'No query provided'})
        }
    
    client = boto3.client('bedrock-agent-runtime', region_name='us-east-1')
    
    try:
        response = client.invoke_agent(
            agentId='WFJKWV1RKB',
            agentAliasId='SNMYYM5VOU',
            sessionId='session-' + context.aws_request_id,
            inputText=query
        )
        
        completion = ""
        for stream_event in response['completion']:
            if 'chunk' in stream_event:
                completion += stream_event['chunk']['bytes'].decode('utf-8')
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'response': completion})
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }